# 来源与许可

压价之王 UndercutKing 由 Momikk 开发和维护，Copyright (C) 2026 Momikk，采用 GNU Affero General Public License version 3 or later（AGPL-3.0-or-later）。完整条款见 LICENSE.md。本软件不提供任何担保。

库存容器 Hook、市场请求 Hook、雇员销售列表顺序映射与高亮交互部分改编自 Critical_Impact 的 Allagan Market（https://github.com/Critical-Impact/AllaganMarket），其原有许可为 AGPL-3.0-or-later，原作者贡献属于原作者。基线为上游 ae150f9366e3c42173362c566f7817c8de56fbd7，以及 Momikk fork 987f688 的国服 7.57 签名修复。

2026-10-13：Momikk 提取并重写为独立插件，移除销售历史、统计、CSV、DalaMock、AllaganLib 和后台 WebSocket；改为当前雇员售价读取、公开 Universalis 查询、游戏市场响应缓存和可恢复的界面高亮。保留原项目来源与许可。

发布二进制时，对应版本的完整源码与构建说明在 RepoUrl 指向的仓库提供。依赖 Dalamud SDK 与 FFXIVClientStructs，遵守各自许可，不在安装包中分发框架程序集。

2026-10-14，0.1.0.7：新增独立实现的 Universalis BSON 消息订阅、批量查询与全局退避。协议及处理思路参考 AllaganLib.Universalis 2.2.0（提交 5b3f414b0796a70ef88d9d77b42ea3c779dcaa16）和 Allagan Market，不引入 AllaganLib 程序集。推送仅触发已扫描商品的完整报价补查，不以增量消息直接替换完整行情。

安装包包含未修改的 MongoDB.Bson 3.5.2，Copyright © 2010-present MongoDB Inc.，采用 Apache-2.0；来源与完整许可见 [THIRD-PARTY-LICENSES.md](THIRD-PARTY-LICENSES.md)。压价之王本身继续采用 AGPL-3.0-or-later。

2026-10-15，0.1.0.10：新增背包匹配格子的临时描框显示，布局与排序映射研究参考 HaselTweaks 的 InventoryHighlight（https://github.com/Haselnussbomber/HaselTweaks，AGPL-3.0）及 FFXIVClientStructs 的 ItemOrderModule/AddonInventoryGrid 结构；格子描框、当前雇员筛选及设置由 Momikk 独立实现，不引入上述插件程序集。

2026-10-17，0.1.0.13：Momikk 将在售数据读取与出售列表显示顺序分离，召唤雇员进入主菜单后即可读取有效记录；增加当前雇员加载归属、在售数量核对及显示顺序验证。沿用前述 Allagan Market 库存交互来源与许可。

2026-10-18，0.1.0.14：Momikk 参考 Allagan Market 的 RetainerMarketService 菜单生命周期读取与 MarketPriceUpdaterService.PostOpen，在 SelectString 显示和关闭前刷新当前雇员记录；保留本插件的槽位映射、有效售价和数据隔离检查。

2026-10-18，0.1.0.16：Momikk 将设置重构为独立实现的原生左侧分类窗口。原生组件使用 KamiToolKit（MidoriKami，MIT），采用套装之王中的 API 15 源码快照，依赖程序集独立命名为 UndercutKing.KamiToolKit。完整来源、修改和许可见 THIRD-PARTY-LICENSES.md 与 vendor/KamiToolKit/LICENSE。

2026-10-18，0.1.0.17：Momikk 将原生设置改为顶部标签，修复 KamiToolKit CheckboxNode.DisableAutoResize 读取值与设置值相反造成的标签截断，扩大帮助按钮以容纳文字。

2026-10-23，0.1.0.21：Momikk 增加可选的回收之王 IPC 兼容。背包蓝框排除正在使用粉色回收标记的物品；无对端或不可调用时保留原有行为。

2026-10-25，0.1.0.23：Momikk 新增非卖品状态保存与过滤。出售列表每行第 7 项是否出售标记的识别参考 NightshadeNx 提交的 Allagan Market PR #42（提交 8a4b386eab0df2f435b55fbd2ae6d48836ae59ed，https://github.com/Critical-Impact/AllaganMarket/pull/42），沿用 AGPL-3.0-or-later。未采用其 0/1 金币价格推断，避免排除正常低价商品。

2026-11-01，0.1.0.25：Momikk 参考 DailyRoutines.ModulesPublic 的 System/AutoRefreshMarketSearchResult.cs（Dalamud-DailyRoutines，AGPL-3.0，https://github.com/Dalamud-DailyRoutines/DailyRoutines.ModulesPublic/blob/4c56b564fb33b9ac8557e52f76c4ca60f706a8f3/System/AutoRefreshMarketSearchResult.cs）与 AtmoOmen/OmenTools 的 GameState.Internal.cs（https://github.com/AtmoOmen/OmenTools/blob/46d0a2e16c71460759b8a226fd4aa08081942148/OmenService/Implementations/Infos/GameState.Internal.cs）研究明确错误后的 RequestData 重试方式。复用本插件已有市场包观察，不复制等待文字内存补丁或增加 OmenTools 依赖；独立实现有限次数退避、上下文取消及 DR 避让。错误码 0x70000003 的含义参考 Dalamud MarketBoardItemRequest 源码。

2026-11-10，0.1.1.0：移除失效的库存容器 Hook，雇员实时读取使用已有菜单生命周期确认当前雇员后读取已加载库存；保留市场响应 Hook、出售顺序映射及有效性校验。
